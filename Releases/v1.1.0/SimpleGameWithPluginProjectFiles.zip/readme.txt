1. close default scene
2. navigate to Main\Scenes
3. Drag and drop both LevelScene and SampleScene into GameObject hierarchy window.