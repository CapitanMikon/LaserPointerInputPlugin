public interface LPIPIInteractable
{ 
    public void LPIPOnLaserHit();
}
